package mael.taskList;

import org.junit.jupiter.api.Test;

public class TestTaskList {
    
}
